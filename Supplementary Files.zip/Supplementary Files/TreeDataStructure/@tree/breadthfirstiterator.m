function iterator = breadthfirstiterator(obj)
    
    f = obj.flatten;
    iterator = [ f{:} ];

end