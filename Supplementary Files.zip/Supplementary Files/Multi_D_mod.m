function Cost = Multi_D_mod( Y_D,D,  Command)

        if Command == "FRF_points"
            yy = Y_D(:,(D+3):100:end); % change this to fix the number of region
            ybar2 = mean(yy,1);
            R_j=sum((yy - ybar2(ones(size(yy,1), 1), :)).^2);
            Cost = sum(R_j);%/size(yy,1);
            
        elseif Command == "FRF_dist_KL"
            yMED=Y_D(:,2:D+1); 
            yVAR=Y_D(:,D+2:2*D+1)    +1e-4;
            Mean_mu=mean(yMED,1);
            Mean_var=mean((yMED-Mean_mu(ones(size(yMED,1), 1), :)).^2+yVAR,1);            
            Mean_var_rep=Mean_var(ones(size(yVAR,1), 1), :);
            Mean_mu_rep=Mean_mu(ones(size(yMED,1), 1), :);
            %%% KL divergence for two univaraitre normal distribution
            R_all=log(sqrt(Mean_var_rep./yVAR))+(yVAR+(yMED-Mean_mu_rep).^2)./(2*Mean_var_rep)-1/2;            
            Cost = sum(sum(R_all));
            
        elseif Command == "FRF_dist_Hell"
            yMED=Y_D(:,2:D+1); 
            yVAR=Y_D(:,D+2:2*D+1)    +1e-4;
            Mean_mu=mean(yMED,1);
            Mean_var=mean((yMED-Mean_mu(ones(size(yMED,1), 1), :)).^2+yVAR,1);            
            Mean_var_rep=Mean_var(ones(size(yVAR,1), 1), :);
            Mean_mu_rep=Mean_mu(ones(size(yMED,1), 1), :);
            %%% Hellinger Distance for two univaraitre normal distribution
            R_all=sqrt(1-sqrt(2*sqrt(Mean_var_rep.*yVAR)./(Mean_var_rep+yVAR)).*exp(-(1/4).*((Mean_mu_rep-yMED).^2./(Mean_var_rep+yVAR))));           
            Cost = sum(sum(R_all));
        end
        
    