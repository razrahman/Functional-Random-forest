function t = split_node_FRT(X,Y,t,t_idx,index, mtree,min_leaf,D, Command)

% calculate which feaure is used for splitting
if length(index)>min_leaf
    [index_left, index_right, which_feature, threshold_feature, D_real,min_score,f_1]...
        = split_FRT(X, Y, index, mtree,D, Command);
    t = t.set(t_idx, [which_feature, threshold_feature, D_real,min_score,f_1]);
    
    [t,tl] = t.addnode(t_idx, 1);
    [t,tr] = t.addnode(t_idx, 2);
    
    t = split_node_FRT(X,Y,t,tl,index_left, mtree,min_leaf,D, Command);
    t = split_node_FRT(X,Y,t,tr,index_right, mtree,min_leaf,D, Command);
else
     
    t = t.set(t_idx, [index', Y(index,:)]);
    
end