function [model] = build_forest(X1, Y1, n_tree, mtree, min_leaf,D, Command)


addpath(genpath(pwd))

[~,bootsam] = bootstrp(n_tree,[],Y1);
model.bootsam = bootsam;

% build forest
forest = cell(1,n_tree);
index=1:size(X1,1);

parfor TT = 1:n_tree
    X=X1(bootsam(:,TT),:);
    Y=Y1(bootsam(:,TT),:);
    
    feature_threshold_t=tree;
    feature_threshold_t = split_node_FRT(X, Y, feature_threshold_t, 1, index, mtree,min_leaf,D, Command);
    forest{1,TT} = feature_threshold_t;
end

model.forest = forest;
% model.variable_num = 1;%%%%%%%%%%%%% size(Y1,2);
model.training_response = Y1;




