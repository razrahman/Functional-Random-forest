function [index_left, index_right, which_feature, threshold_feature, D_real,min_score,f_1] ...
    = split_FRT(X, Y, index, mtree,D1, Command)

x = X(index,:);
y = Y(index,:);

f = size(x,2); % number of features
f_1 = sort(randperm(f, mtree));
N = size(x,1); % number of samples
id = cell(N-1,length(f_1));
D_real = Multi_D_mod(y, D1, Command);

for Feature = 1:length(f_1)
    
    xj = x(:,f_1(Feature));
    [s, idx] = sort(xj); % sort the features
    
    for Sample = 1:(N-1) % calculate D(N)
        
        yk_left = y(idx(1:Sample),:);
        yk_right = y(idx(Sample+1:end),:);
        D_left = Multi_D_mod(yk_left, D1, Command);
        D_right = Multi_D_mod(yk_right,D1,  Command);
        D = D_left + D_right;

        if Feature==1 && Sample==1
            min_score = D;
            which_feature = f_1(1);
            threshold_feature = (s(Sample) + s(Sample+1))/2;
            ij_i = 1;
            ij_j = 1;
        end
        
        if D < min_score %&& D < D_real
            min_score = D;
            which_feature = f_1(Feature);                % which feature determines the split
            threshold_feature = (s(Sample) + s(Sample+1))/2; % threshold calculation
            ij_i = Sample;
            ij_j = Feature;
        end
        id{Sample,Feature} = idx(1:Sample);
      
    end
end

index_left = id{ij_i,ij_j};
index_right = 1:N;
index_right(index_left) =[];

index_left = index(sort(index_left));
index_right = index(sort(index_right));

